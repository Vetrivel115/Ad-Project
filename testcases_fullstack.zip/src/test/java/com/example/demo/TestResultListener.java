package com.example.demo;

import org.testng.ITestListener;
import org.testng.ITestResult;
import java.util.Map;
import java.util.HashMap;

public class TestResultListener implements ITestListener {

    private static final Map<String, String> DESCRIPTIONS = new HashMap<>();
    
    static {
        DESCRIPTIONS.put("t1", "Verify Primary Controller exists");
        DESCRIPTIONS.put("t2", "Verify Primary Service exists");
        DESCRIPTIONS.put("t3", "Verify Primary Repository is an interface");
        DESCRIPTIONS.put("t4", "Verify Primary Entity has @Entity and @Table annotation");
        DESCRIPTIONS.put("t5", "Verify SecurityConfig has @Configuration annotation");
        DESCRIPTIONS.put("t6", "Verify Primary Controller uses @RequestMapping with correct base path");
        DESCRIPTIONS.put("t7", "Verify Primary Controller GET endpoint returns 200 OK");
        DESCRIPTIONS.put("t8", "Verify Primary Controller DELETE endpoint returns 200 OK");
        DESCRIPTIONS.put("t9", "Verify Primary Controller POST endpoint returns 201 CREATED");
        DESCRIPTIONS.put("t10", "Verify Primary Controller PUT endpoint returns 200 OK");
        DESCRIPTIONS.put("t11", "Verify Primary Controller GET by ID returns 200 OK");
        DESCRIPTIONS.put("t12", "Verify Secondary Controller exists");
        DESCRIPTIONS.put("t13", "Verify admin role access via @PreAuthorize");
        DESCRIPTIONS.put("t14", "Verify driver role access via @PreAuthorize");
        DESCRIPTIONS.put("t15", "Verify @PreAuthorize is used on controller methods");
        DESCRIPTIONS.put("t16", "Verify SystemUserRepository exists");
        DESCRIPTIONS.put("t17", "Verify GlobalExceptionHandler has @ControllerAdvice");
        DESCRIPTIONS.put("t18", "Verify ResourceNotFoundException exists");
        DESCRIPTIONS.put("t19", "Verify JwtService exists");
        DESCRIPTIONS.put("t20", "Verify JwtService has generateToken method");
        DESCRIPTIONS.put("t21", "Verify JwtService has isTokenValid method");
        DESCRIPTIONS.put("t22", "Verify JwtService has extractUsername method");
        DESCRIPTIONS.put("t23", "Verify Trip entity exists");
        DESCRIPTIONS.put("t24", "Verify Primary Service has dependencies declared");
        DESCRIPTIONS.put("t25", "Verify TripService exists and has methods");
        DESCRIPTIONS.put("t26", "Verify MaintenanceLogRepository extends JpaRepository");
        DESCRIPTIONS.put("t27", "Verify AlertRepository extends JpaRepository");
        DESCRIPTIONS.put("t28", "Verify SecurityConfig configures SecurityFilterChain bean");
        DESCRIPTIONS.put("t29", "Verify ResourceNotFoundException has @ResponseStatus");
        DESCRIPTIONS.put("t30", "Verify Primary Service uses constructor injection");
    }

    private String getTestDescription(ITestResult result) {
        String methodName = result.getMethod().getMethodName();
        String description = result.getMethod().getDescription();
        if (description != null && !description.isEmpty()) {
            return methodName + " - " + description;
        }
        return methodName + " - " + DESCRIPTIONS.getOrDefault(methodName, "No description available");
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        System.out.println(getTestDescription(result) + " - PASS");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        System.out.println(getTestDescription(result) + " - FAIL");
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        System.out.println(getTestDescription(result) + " - SKIP");
    }
}
