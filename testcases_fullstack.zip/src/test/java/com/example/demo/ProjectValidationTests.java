package com.example.demo;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.mockito.Mockito;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@Listeners(TestResultListener.class)
public class ProjectValidationTests {

    private static final String PRIMARY_CONTROLLER = "com.example.demo.controller.VehicleController";
    private static final String PRIMARY_SERVICE = "com.example.demo.service.VehicleService";
    private static final String PRIMARY_REPOSITORY = "com.example.demo.repository.VehicleRepository";
    private static final String PRIMARY_ENTITY = "com.example.demo.entity.Vehicle";
    private static final String SECONDARY_CONTROLLER = "com.example.demo.controller.MaintenanceController";
    
    private static final String API_BASE_PATH = "/api/vehicles";
    private static final String TABLE_NAME = "vehicles";
    private static final String DOMAIN_ROLE = "DRIVER";
    
    private static final String CRUD_DELETE_MSG = "Vehicle deleted successfully.";
    private static final String CRUD_CREATE_MSG = "Vehicle created successfully.";
    private static final String CRUD_UPDATE_MSG = "Vehicle updated successfully.";
    
    private static final String DOMAIN_VALUE_1 = "ABC-1234";
    private static final String DOMAIN_VALUE_2 = "Volvo FH16";

    // DAY-1 | Sprint: Package & Layer Architecture Verification

    @Test
    public void testPrimaryControllerLoadsSuccessfully() throws Exception {
        Class<?> clazz = Class.forName(PRIMARY_CONTROLLER);
        Assert.assertNotNull(clazz);
        Assert.assertTrue(clazz.getDeclaredMethods().length > 0);
    }

    @Test
    public void testPrimaryServiceLoadsSuccessfully() throws Exception {
        Class<?> clazz = Class.forName(PRIMARY_SERVICE);
        Assert.assertNotNull(clazz);
        Assert.assertTrue(clazz.getDeclaredMethods().length >= 3);
    }

    @Test
    public void testPrimaryRepositoryIsInterface() throws Exception {
        Class<?> clazz = Class.forName(PRIMARY_REPOSITORY);
        Assert.assertTrue(clazz.isInterface());
    }

    @Test
    public void testPrimaryEntityHasJpaAnnotations() throws Exception {
        Class<?> clazz = Class.forName(PRIMARY_ENTITY);
        Assert.assertNotNull(clazz.getAnnotation(jakarta.persistence.Entity.class));
        jakarta.persistence.Table table = clazz.getAnnotation(jakarta.persistence.Table.class);
        Assert.assertEquals(table.name(), TABLE_NAME);
    }

    @Test
    public void testSecurityConfigHasConfigurationAnnotation() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.config.SecurityConfig");
        Assert.assertTrue(clazz.isAnnotationPresent(org.springframework.context.annotation.Configuration.class));
    }

    // DAY-2 | Sprint: Full CRUD Response Verification via Reflection

    @Test
    public void testControllerRequestMappingPathIsCorrect() throws Exception {
        Class<?> clazz = Class.forName(PRIMARY_CONTROLLER);
        org.springframework.web.bind.annotation.RequestMapping rm = clazz.getAnnotation(org.springframework.web.bind.annotation.RequestMapping.class);
        Assert.assertEquals(rm.value()[0], API_BASE_PATH);
    }

    @Test
    public void testGetAllVehiclesEndpointReturnsOkStatus() throws Exception {
        Class<?> controllerClazz = Class.forName(PRIMARY_CONTROLLER);
        Class<?> serviceClazz = Class.forName(PRIMARY_SERVICE);
        Class<?> entityClazz = Class.forName(PRIMARY_ENTITY);

        Object mockService = Mockito.mock(serviceClazz);
        Object entity = entityClazz.getDeclaredConstructor().newInstance();
        entityClazz.getMethod("setLicensePlate", String.class).invoke(entity, DOMAIN_VALUE_1);
        
        when(serviceClazz.getMethod("getAllVehicles", org.springframework.data.domain.Pageable.class).invoke(mockService, any(org.springframework.data.domain.Pageable.class)))
            .thenReturn(new org.springframework.data.domain.PageImpl<>(Collections.singletonList(entity)));

        Object controller = controllerClazz.getDeclaredConstructors()[0].newInstance(mockService, null);
        Method getAllMethod = null;
        for(Method m : controllerClazz.getDeclaredMethods()) {
            if(m.isAnnotationPresent(org.springframework.web.bind.annotation.GetMapping.class) && m.getParameterCount() == 2) {
                getAllMethod = m;
                break;
            }
        }
        
        Object response = getAllMethod.invoke(controller, 0, 10);
        org.springframework.http.ResponseEntity<?> respEntity = (org.springframework.http.ResponseEntity<?>) response;
        Assert.assertEquals(respEntity.getStatusCode().toString(), "200 OK");
    }

    @Test
    public void testDeleteVehicleEndpointReturnsSuccessMessage() throws Exception {
        Class<?> controllerClazz = Class.forName(PRIMARY_CONTROLLER);
        Class<?> serviceClazz = Class.forName(PRIMARY_SERVICE);
        Object mockService = Mockito.mock(serviceClazz);
        
        Object controller = controllerClazz.getDeclaredConstructors()[0].newInstance(mockService, null);
        Method deleteMethod = null;
        for(Method m : controllerClazz.getDeclaredMethods()) {
            if(m.isAnnotationPresent(org.springframework.web.bind.annotation.DeleteMapping.class)) {
                deleteMethod = m;
                break;
            }
        }
        
        Object response = deleteMethod.invoke(controller, 1L);
        org.springframework.http.ResponseEntity<?> respEntity = (org.springframework.http.ResponseEntity<?>) response;
        Assert.assertEquals(respEntity.getStatusCode().toString(), "200 OK");
        Assert.assertEquals(respEntity.getBody(), CRUD_DELETE_MSG);
    }

    @Test
    public void testCreateVehicleEndpointReturnsCreatedStatus() throws Exception {
        Class<?> controllerClazz = Class.forName(PRIMARY_CONTROLLER);
        Class<?> serviceClazz = Class.forName(PRIMARY_SERVICE);
        Object mockService = Mockito.mock(serviceClazz);
        
        Object controller = controllerClazz.getDeclaredConstructors()[0].newInstance(mockService, null);
        Method createMethod = null;
        for(Method m : controllerClazz.getDeclaredMethods()) {
            if(m.isAnnotationPresent(org.springframework.web.bind.annotation.PostMapping.class)) {
                createMethod = m;
                break;
            }
        }
        
        Object entity = Class.forName(PRIMARY_ENTITY).getDeclaredConstructor().newInstance();
        Object response = createMethod.invoke(controller, entity);
        org.springframework.http.ResponseEntity<?> respEntity = (org.springframework.http.ResponseEntity<?>) response;
        Assert.assertEquals(respEntity.getStatusCode().toString(), "201 CREATED");
        Assert.assertEquals(respEntity.getBody(), CRUD_CREATE_MSG);
    }

    @Test
    public void testUpdateVehicleEndpointReturnsOkStatus() throws Exception {
        Class<?> controllerClazz = Class.forName(PRIMARY_CONTROLLER);
        Class<?> serviceClazz = Class.forName(PRIMARY_SERVICE);
        Object mockService = Mockito.mock(serviceClazz);
        
        Object controller = controllerClazz.getDeclaredConstructors()[0].newInstance(mockService, null);
        Method updateMethod = null;
        for(Method m : controllerClazz.getDeclaredMethods()) {
            if(m.isAnnotationPresent(org.springframework.web.bind.annotation.PutMapping.class)) {
                updateMethod = m;
                break;
            }
        }
        
        Object entity = Class.forName(PRIMARY_ENTITY).getDeclaredConstructor().newInstance();
        Object response = updateMethod.invoke(controller, 1L, entity);
        org.springframework.http.ResponseEntity<?> respEntity = (org.springframework.http.ResponseEntity<?>) response;
        Assert.assertEquals(respEntity.getStatusCode().toString(), "200 OK");
        Assert.assertEquals(respEntity.getBody(), CRUD_UPDATE_MSG);
    }

    @Test
    public void testGetVehicleByIdEndpointReturnsEntity() throws Exception {
        Class<?> controllerClazz = Class.forName(PRIMARY_CONTROLLER);
        Class<?> serviceClazz = Class.forName(PRIMARY_SERVICE);
        Class<?> entityClazz = Class.forName(PRIMARY_ENTITY);
        Object mockService = Mockito.mock(serviceClazz);
        
        Object entity = entityClazz.getDeclaredConstructor().newInstance();
        entityClazz.getMethod("setId", Long.class).invoke(entity, 1L);
        when(serviceClazz.getMethod("getVehicleById", Long.class).invoke(mockService, 1L)).thenReturn(entity);

        Object controller = controllerClazz.getDeclaredConstructors()[0].newInstance(mockService, null);
        Method getByIdMethod = null;
        for(Method m : controllerClazz.getDeclaredMethods()) {
            if(m.isAnnotationPresent(org.springframework.web.bind.annotation.GetMapping.class) && m.getParameterCount() == 1) {
                getByIdMethod = m;
                break;
            }
        }
        
        Object response = getByIdMethod.invoke(controller, 1L);
        org.springframework.http.ResponseEntity<?> respEntity = (org.springframework.http.ResponseEntity<?>) response;
        Assert.assertEquals(respEntity.getStatusCode().toString(), "200 OK");
    }

    @Test
    public void testSecondaryControllerLoadsSuccessfully() throws Exception {
        Class<?> controllerClazz = Class.forName(SECONDARY_CONTROLLER);
        Assert.assertNotNull(controllerClazz);
    }

    // DAY-3 | Sprint: Security Annotations, RBAC & CORS

    @Test
    public void testAdminRolePreAuthorizeAnnotationExists() throws Exception {
        Class<?> clazz = Class.forName(PRIMARY_CONTROLLER);
        boolean hasAdminGated = false;
        for (Method m : clazz.getDeclaredMethods()) {
            org.springframework.security.access.prepost.PreAuthorize pre = m.getAnnotation(org.springframework.security.access.prepost.PreAuthorize.class);
            if (pre != null && pre.value().contains("FLEET_MANAGER")) {
                hasAdminGated = true;
                break;
            }
        }
        Assert.assertTrue(hasAdminGated);
    }

    @Test
    public void testDomainRolePreAuthorizeAnnotationExists() throws Exception {
        Class<?> clazz = Class.forName(PRIMARY_CONTROLLER);
        boolean hasDriverGated = false;
        for (Method m : clazz.getDeclaredMethods()) {
            org.springframework.security.access.prepost.PreAuthorize pre = m.getAnnotation(org.springframework.security.access.prepost.PreAuthorize.class);
            if (pre != null && pre.value().contains(DOMAIN_ROLE)) {
                hasDriverGated = true;
                break;
            }
        }
        Assert.assertTrue(hasDriverGated);
    }

    @Test
    public void testMultiplePreAuthorizeAnnotationsApplied() throws Exception {
        Class<?> clazz = Class.forName(PRIMARY_CONTROLLER);
        int count = 0;
        for (Method m : clazz.getDeclaredMethods()) {
            if (m.isAnnotationPresent(org.springframework.security.access.prepost.PreAuthorize.class)) {
                count++;
            }
        }
        Assert.assertTrue(count >= 2);
    }

    // DAY-4 | Sprint: Repository Custom Queries & Exception Handling

    @Test
    public void testSystemUserRepositoryLoadsSuccessfully() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.repository.SystemUserRepository");
        Assert.assertNotNull(clazz);
    }

    @Test
    public void testGlobalExceptionHandlerHasControllerAdvice() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.exception.GlobalExceptionHandler");
        Assert.assertTrue(clazz.isAnnotationPresent(org.springframework.web.bind.annotation.ControllerAdvice.class));
    }

    @Test
    public void testResourceNotFoundExceptionClassExists() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.exception.ResourceNotFoundException");
        Assert.assertNotNull(clazz);
    }

    // DAY-5 | Sprint: JWT Token Generation & Validation

    @Test
    public void testJwtServiceClassExists() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.service.JwtService");
        Assert.assertNotNull(clazz);
    }

    @Test
    public void testJwtServiceHasGenerateTokenMethod() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.service.JwtService");
        Assert.assertNotNull(clazz.getDeclaredMethod("generateToken", org.springframework.security.core.userdetails.UserDetails.class));
    }

    @Test
    public void testJwtServiceHasValidateTokenMethod() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.service.JwtService");
        Assert.assertNotNull(clazz.getDeclaredMethod("isTokenValid", String.class, org.springframework.security.core.userdetails.UserDetails.class));
    }

    @Test
    public void testJwtServiceHasExtractUsernameMethod() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.service.JwtService");
        Assert.assertNotNull(clazz.getDeclaredMethod("extractUsername", String.class));
    }

    // DAY-6 | Sprint: Entity DB Mapping & Filter Chain

    @Test
    public void testTripEntityLoadsSuccessfully() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.entity.Trip");
        Assert.assertNotNull(clazz);
    }

    @Test
    public void testPrimaryServiceHasDependenciesInjected() throws Exception {
        Class<?> serviceClazz = Class.forName(PRIMARY_SERVICE);
        Assert.assertTrue(serviceClazz.getDeclaredFields().length >= 1);
    }

    @Test
    public void testTripServiceHasMethodsDefined() throws Exception {
        Class<?> serviceClazz = Class.forName("com.example.demo.service.TripService");
        Assert.assertTrue(serviceClazz.getDeclaredMethods().length > 0);
    }

    // DAY-7 | Sprint: Additional Quality Checks

    @Test
    public void testMaintenanceLogRepositoryExtendsJpaRepository() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.repository.MaintenanceLogRepository");
        Assert.assertTrue(org.springframework.data.jpa.repository.JpaRepository.class.isAssignableFrom(clazz));
    }

    @Test
    public void testAlertRepositoryExtendsJpaRepository() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.repository.AlertRepository");
        Assert.assertTrue(org.springframework.data.jpa.repository.JpaRepository.class.isAssignableFrom(clazz));
    }

    @Test
    public void testSecurityConfigHasFilterChainBean() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.config.SecurityConfig");
        boolean hasFilterChain = false;
        for (Method m : clazz.getDeclaredMethods()) {
            if (m.isAnnotationPresent(org.springframework.context.annotation.Bean.class) && m.getReturnType().equals(org.springframework.security.web.SecurityFilterChain.class)) {
                hasFilterChain = true;
                break;
            }
        }
        Assert.assertTrue(hasFilterChain);
    }

    @Test
    public void testResourceNotFoundExceptionHasResponseStatusAnnotation() throws Exception {
        Class<?> clazz = Class.forName("com.example.demo.exception.ResourceNotFoundException");
        Assert.assertTrue(clazz.isAnnotationPresent(org.springframework.web.bind.annotation.ResponseStatus.class));
    }

    @Test
    public void testPrimaryServiceHasConstructorsDefined() throws Exception {
        Class<?> clazz = Class.forName(PRIMARY_SERVICE);
        Assert.assertTrue(clazz.getConstructors().length > 0);
    }
}